package com.sinclair.music.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.store by preferencesDataStore("sinclair_music")
class UserStore(private val context: Context) {
    private val favorites = stringSetPreferencesKey("favorites")
    private val playlists = stringSetPreferencesKey("playlists")
    val favoriteIds: Flow<Set<Long>> = context.store.data.map { p ->
        p[favorites].orEmpty().mapNotNull { it.toLongOrNull() }.toSet()
    }
    val playlistNames: Flow<Set<String>> = context.store.data.map { it[playlists].orEmpty() }

    suspend fun toggleFavorite(id: Long) {
        context.store.edit { p ->
            val current = p[favorites].orEmpty().toMutableSet()
            if (!current.add(id.toString())) current.remove(id.toString())
            p[favorites] = current
        }
    }
    suspend fun addPlaylist(name: String) {
        context.store.edit { p ->
            p[playlists] = p[playlists].orEmpty() + name
        }
    }
}
