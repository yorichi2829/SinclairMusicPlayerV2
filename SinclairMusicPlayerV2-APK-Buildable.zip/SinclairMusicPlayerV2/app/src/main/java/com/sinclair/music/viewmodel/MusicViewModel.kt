package com.sinclair.music.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.sinclair.music.data.MusicRepository
import com.sinclair.music.data.UserStore
import com.sinclair.music.model.MusicTrack
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class SortMode { TITLE, ARTIST, ALBUM, DURATION }

class MusicViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = MusicRepository(app.contentResolver)
    private val store = UserStore(app)

    val tracks = MutableStateFlow<List<MusicTrack>>(emptyList())
    val query = MutableStateFlow("")
    val sort = MutableStateFlow(SortMode.TITLE)
    val favorites = store.favoriteIds.stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())
    val playlists = store.playlistNames.stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())

    init { refresh() }

    fun refresh() = viewModelScope.launch { tracks.value = repo.scan() }
    fun search(v: String) { query.value = v }
    fun setSort(v: SortMode) { sort.value = v }
    fun favorite(id: Long) = viewModelScope.launch { store.toggleFavorite(id) }
    fun createPlaylist(name: String) = viewModelScope.launch { store.addPlaylist(name) }

    fun visible(): List<MusicTrack> {
        val q = query.value.trim()
        val filtered = if (q.isBlank()) tracks.value else tracks.value.filter {
            it.title.contains(q, true) || it.artist.contains(q, true) || it.album.contains(q, true)
        }
        return when (sort.value) {
            SortMode.TITLE -> filtered.sortedBy { it.title.lowercase() }
            SortMode.ARTIST -> filtered.sortedBy { it.artist.lowercase() }
            SortMode.ALBUM -> filtered.sortedBy { it.album.lowercase() }
            SortMode.DURATION -> filtered.sortedByDescending { it.durationMs }
        }
    }
}
