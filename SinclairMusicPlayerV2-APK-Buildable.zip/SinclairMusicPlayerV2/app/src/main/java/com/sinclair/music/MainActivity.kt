package com.sinclair.music

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.viewmodel.compose.viewModel
import com.sinclair.music.ui.SinclairTheme
import com.sinclair.music.ui.SinclairApp
import com.sinclair.music.viewmodel.MusicViewModel

class MainActivity : ComponentActivity() {
    private val request = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {}
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val permissions = buildList {
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.READ_MEDIA_AUDIO)
            else add(Manifest.permission.READ_EXTERNAL_STORAGE)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        }
        request.launch(permissions.toTypedArray())
        setContent {
            SinclairTheme { SinclairApp(viewModel<MusicViewModel>()) }
        }
    }
}
