package com.sinclair.music.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil3.compose.AsyncImage
import com.sinclair.music.model.MusicTrack
import com.sinclair.music.playback.PlayerConnection
import com.sinclair.music.viewmodel.MusicViewModel
import com.sinclair.music.viewmodel.SortMode
import kotlinx.coroutines.guava.await

@Composable
fun SinclairApp(vm: MusicViewModel) {
    val tracks by vm.tracks.collectAsStateWithLifecycle()
    val favorites by vm.favorites.collectAsStateWithLifecycle()
    val playlists by vm.playlists.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()
    var tab by remember { mutableIntStateOf(0) }
    var search by remember { mutableStateOf(false) }
    var current by remember { mutableStateOf<MusicTrack?>(null) }
    var showSettings by remember { mutableStateOf(false) }
    var showPlaylist by remember { mutableStateOf(false) }
    val visible = vm.visible()

    Scaffold(
        containerColor = Color(0xFF08090C),
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF0D0F14)) {
                listOf("Home","Library","Favorites","Playlists").forEachIndexed { i, label ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(if (i==0) Icons.Default.Home else if(i==1) Icons.Default.LibraryMusic else if(i==2) Icons.Default.Favorite else Icons.Default.QueueMusic, null) },
                        label = { Text(label) }
                    )
                }
            }
        }
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("SINCLAIR", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Text("Your music.", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
                }
                IconButton({ search = !search }) { Icon(Icons.Default.Search, null) }
                IconButton({ showSettings = true }) { Icon(Icons.Default.Settings, null) }
            }
            if (search) {
                OutlinedTextField(
                    query, vm::search, Modifier.fillMaxWidth().padding(horizontal=20.dp),
                    placeholder={Text("Search songs, artists, albums")}, singleLine=true
                )
                Spacer(Modifier.height(10.dp))
            }

            when(tab) {
                0 -> Home(visible, favorites, vm) { current = it }
                1 -> Library(visible, favorites, vm) { current = it }
                2 -> Library(visible.filter { it.id in favorites }, favorites, vm) { current = it }
                3 -> Playlists(playlists, onAdd={showPlaylist=true})
            }
        }
    }

    current?.let { NowPlaying(it, visible, vm) { current=null } }
    if (showSettings) Settings(vm, {showSettings=false})
    if (showPlaylist) NewPlaylist(vm) {showPlaylist=false}
}

@Composable
private fun Home(tracks: List<MusicTrack>, fav: Set<Long>, vm: MusicViewModel, open:(MusicTrack)->Unit) {
    Column {
        Box(Modifier.padding(horizontal=20.dp).fillMaxWidth().height(155.dp).clip(RoundedCornerShape(28.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF7D5CFF), Color(0xFFB9F227))))) {
            Column(Modifier.padding(22.dp)) {
                Text("OFFLINE MODE", color=Color.Black, fontWeight=FontWeight.Bold)
                Text("All your music,\nright on your device.", color=Color.Black,
                    style=MaterialTheme.typography.headlineSmall, fontWeight=FontWeight.ExtraBold)
            }
        }
        Spacer(Modifier.height(20.dp))
        Text("Recently added", Modifier.padding(horizontal=20.dp), style=MaterialTheme.typography.titleLarge, fontWeight=FontWeight.Bold)
        TrackList(tracks.take(15),fav,vm,open)
    }
}

@Composable
private fun Library(tracks: List<MusicTrack>, fav:Set<Long>, vm:MusicViewModel, open:(MusicTrack)->Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal=20.dp), verticalAlignment=Alignment.CenterVertically) {
        Text("${tracks.size} songs", Modifier.weight(1f), color=MaterialTheme.colorScheme.onSurfaceVariant)
        var expanded by remember { mutableStateOf(false) }
        Box {
            TextButton({expanded=true}) { Text("Sort") }
            DropdownMenu(expanded,{expanded=false}) {
                SortMode.entries.forEach { mode ->
                    DropdownMenuItem({ Text(mode.name.lowercase().replaceFirstChar{it.uppercase()}) },
                        {vm.setSort(mode);expanded=false})
                }
            }
        }
    }
    TrackList(tracks,fav,vm,open)
}

@Composable
private fun TrackList(tracks:List<MusicTrack>, fav:Set<Long>, vm:MusicViewModel, open:(MusicTrack)->Unit) {
    LazyColumn(contentPadding=PaddingValues(16.dp), verticalArrangement=Arrangement.spacedBy(5.dp)) {
        items(tracks,key={it.id}) { t ->
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).clickable{open(t)}.padding(9.dp),
                verticalAlignment=Alignment.CenterVertically) {
                AsyncImage(t.artworkUri ?: t.uri,t.album,Modifier.size(58.dp).clip(RoundedCornerShape(14.dp)))
                Spacer(Modifier.width(13.dp))
                Column(Modifier.weight(1f)) {
                    Text(t.title,maxLines=1,fontWeight=FontWeight.SemiBold)
                    Text("${t.artist} • ${t.album}",maxLines=1,color=MaterialTheme.colorScheme.onSurfaceVariant,
                        style=MaterialTheme.typography.bodySmall)
                }
                IconButton({vm.favorite(t.id)}) {
                    Icon(if(t.id in fav) Icons.Default.Favorite else Icons.Default.FavoriteBorder,null,
                        tint=if(t.id in fav) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun Playlists(names:Set<String>,onAdd:()->Unit) {
    Column(Modifier.padding(20.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically) {
            Text("Your playlists",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold,Modifier.weight(1f))
            FilledTonalButton(onAdd){Icon(Icons.Default.Add,null);Spacer(Modifier.width(5.dp));Text("New")}
        }
        Spacer(Modifier.height(14.dp))
        names.forEach { name ->
            ListItem(
                headlineContent={Text(name,fontWeight=FontWeight.SemiBold)},
                supportingContent={Text("Offline playlist")},
                leadingContent={Icon(Icons.Default.QueueMusic,null)}
            )
        }
        if(names.isEmpty()) Text("Create your first playlist.",color=MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun NewPlaylist(vm:MusicViewModel,close:()->Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest=close,title={Text("New playlist")},
        text={OutlinedTextField(name,{name=it},label={Text("Playlist name")},singleLine=true)},
        confirmButton={TextButton({if(name.isNotBlank()){vm.createPlaylist(name.trim());close()}}){Text("Create")}},
        dismissButton={TextButton(close){Text("Cancel")}})
}

@Composable
private fun Settings(vm:MusicViewModel,close:()->Unit) {
    AlertDialog(onDismissRequest=close,title={Text("Settings")},
        text={Column {
            Text("Sinclair Music",fontWeight=FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Text("Offline-first player • Media3 playback • Android system controls")
            Spacer(Modifier.height(12.dp))
            TextButton({vm.refresh();close()}) { Text("Rescan music library") }
        }},
        confirmButton={TextButton(close){Text("Done")}})
}

@Composable
private fun NowPlaying(track:MusicTrack,queue:List<MusicTrack>,vm:MusicViewModel,close:()->Unit) {
    val connection=remember{PlayerConnection(LocalContext.current)}
    val controller by produceState<androidx.media3.session.MediaController?>(null) { value=connection.future.await() }
    ModalBottomSheet(onDismissRequest=close,containerColor=Color(0xFF101217)) {
        Column(Modifier.fillMaxWidth().padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally) {
            Text("NOW PLAYING",color=MaterialTheme.colorScheme.primary,fontWeight=FontWeight.Bold)
            Spacer(Modifier.height(14.dp))
            AsyncImage(track.artworkUri ?: track.uri,track.album,Modifier.size(300.dp).clip(RoundedCornerShape(28.dp)))
            Spacer(Modifier.height(22.dp))
            Text(track.title,style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.ExtraBold)
            Text(track.artist,color=MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(18.dp))
            Slider(0f,{})
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly,verticalAlignment=Alignment.CenterVertically) {
                IconButton({controller?.setShuffleModeEnabled(!(controller?.shuffleModeEnabled ?: false))}) {Icon(Icons.Default.Shuffle,null)}
                IconButton({controller?.seekToPrevious()}) {Icon(Icons.Default.SkipPrevious,null,Modifier.size(40.dp))}
                FilledIconButton({controller?.let{c->if(c.isPlaying)c.pause() else {c.setMediaItem(track.mediaItem());c.prepare();c.play()}}},Modifier.size(70.dp)) {
                    Icon(Icons.Default.PlayArrow,null,Modifier.size(38.dp))
                }
                IconButton({controller?.seekToNext()}) {Icon(Icons.Default.SkipNext,null,Modifier.size(40.dp))}
                IconButton({controller?.setRepeatMode(androidx.media3.common.Player.REPEAT_MODE_ALL)}) {Icon(Icons.Default.Repeat,null)}
            }
            Spacer(Modifier.height(12.dp))
            Text("Sleep timer • Lyrics • Queue",color=MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(20.dp))
        }
    }
}
