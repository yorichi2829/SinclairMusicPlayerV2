package com.sinclair.music.ui
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

@Composable
fun SinclairTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFFB9F227),
            secondary = Color(0xFF7D5CFF),
            background = Color(0xFF08090C),
            surface = Color(0xFF12141A),
            onPrimary = Color.Black
        ),
        content = content
    )
}
