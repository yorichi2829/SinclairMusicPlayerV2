package com.sinclair.music.playback

import android.content.ComponentName
import android.content.Context
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.sinclair.music.model.MusicTrack

class PlayerConnection(context: Context) {
    private val app = context.applicationContext
    private val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
    val future = MediaController.Builder(app, token).buildAsync()

    fun play(controller: MediaController, tracks: List<MusicTrack>, index: Int) {
        controller.setMediaItems(tracks.map { it.mediaItem() }, index, 0L)
        controller.prepare()
        controller.play()
    }
}
