package com.sinclair.music.data

import android.content.ContentResolver
import android.content.ContentUris
import android.provider.MediaStore
import com.sinclair.music.model.MusicTrack
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MusicRepository(private val resolver: ContentResolver) {
    suspend fun scan(): List<MusicTrack> = withContext(Dispatchers.IO) {
        val list = mutableListOf<MusicTrack>()
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.ALBUM_ID
        )
        resolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            projection,
            "${MediaStore.Audio.Media.IS_MUSIC} != 0",
            null,
            "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        )?.use { c ->
            val id = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val title = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val album = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val duration = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val albumId = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            while (c.moveToNext()) {
                val songId = c.getLong(id)
                val aid = c.getLong(albumId)
                list += MusicTrack(
                    songId,
                    c.getString(title).orEmpty().ifBlank { "Unknown title" },
                    c.getString(artist).orEmpty().ifBlank { "Unknown artist" },
                    c.getString(album).orEmpty().ifBlank { "Unknown album" },
                    c.getLong(duration),
                    ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, songId),
                    aid,
                    ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), aid)
                )
            }
        }
        list
    }
}
